let boxes = document.querySelectorAll('.color-div')
let guesscolorSpan = document.querySelector('.guesscolorSpan')
let scoreSpan = document.querySelector('.scoreSpan')
let swap = document.querySelector('.swap')

let guessColor;
let score = 0;
let level;




function game(a) {
    level = a
    let displayTohex = false
    for (i = 0; i < boxes.length; i++) {
        if (i < a) {
            let r = Math.floor(Math.random() * 256)
            let g = Math.floor(Math.random() * 256)
            let b = Math.floor(Math.random() * 256)
            boxes[i].style.backgroundColor = `rgb(${r}, ${g}, ${b})`
            boxes[i].style.opacity = 1
        } else {
            boxes[i].style.opacity = 0
        }
    }

    guessColor = boxes[Math.floor(Math.random() * a)].style.backgroundColor
    guesscolorSpan.innerHTML = guessColor

    swap.addEventListener('click', function () {
        if (displayTohex) {
            guesscolorSpan.innerHTML = guessColor;
            displayTohex = false;
        } else {
            let rgbValues = guessColor.match(/\d+/g);
            let r0 = parseInt(rgbValues[0]);
            let g0 = parseInt(rgbValues[1]);
            let b0 = parseInt(rgbValues[2])
            var hexColor = "#" + componentToHex(r0) + componentToHex(g0) +
                componentToHex(b0);

            function componentToHex(c) {
                var hex = c.toString(16);
                return hex.length == 1 ? "0" + hex : hex;
            }



            guesscolorSpan.innerHTML = hexColor;
            displayTohex = true;

        }
    })

    if (score >= 50) {
        alert('Congratulations, You won')
    }

}

for (let box of boxes) {
    box.addEventListener('click', function () {
        if (box.style.backgroundColor == guessColor) {
            score += (level / 3) * 10;
            alert('success')
            game(level)
        } else {
            score -= (level / 3) * 5;
            alert('fail')
            game(level)
        }
        scoreSpan.innerHTML = score
    }

    )



}


function reset() {
    location.reload()
}



